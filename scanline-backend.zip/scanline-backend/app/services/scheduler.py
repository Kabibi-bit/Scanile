"""Background job that scans real listings daily and re-scores them
for every user with an active profile. This is what makes the
"continuous overnight watch" real instead of a UI animation.
"""
import os
import asyncio
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from sqlalchemy.orm import Session
import anthropic

from app.db import SessionLocal
from app.models.db_models import User, Profile, Listing, MatchScore
from app.services.ingestion import fetch_adzuna, normalize_adzuna, dedupe_listings, extract_tags
from app.services.matching import rank_listings

SCAN_INTERVAL_MINUTES = int(os.getenv("SCAN_INTERVAL_MINUTES", "1440"))  # default: once/day
anthropic_client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))


def _profile_to_dict(p: Profile) -> dict:
    return {
        "northstar": p.northstar,
        "final_idea": p.final_idea or "",
        "skills": p.skills or "",
        "dealbreakers": p.dealbreakers or "",
        "priorities": p.priorities or [],
        "target_types": p.target_types or [],
    }


def _listing_to_dict(l: Listing) -> dict:
    return {
        "id": str(l.id),
        "type": l.type,
        "title": l.title,
        "org": l.org,
        "tags": l.tags or [],
        "location": l.location,
        "deadline": l.deadline.isoformat() if l.deadline else None,
    }


async def _pull_and_store_new_listings(db: Session, query: str = "internship"):
    """Fetches real listings from Adzuna, tags them via Claude, and
    upserts anything new into the listings table.
    """
    raw_results = await fetch_adzuna(query)
    normalized = dedupe_listings([normalize_adzuna(r) for r in raw_results])

    stored_count = 0
    for item in normalized:
        exists = (
            db.query(Listing)
            .filter(Listing.source == item["source"], Listing.external_id == item["external_id"])
            .first()
        )
        if exists:
            continue
        tags = await extract_tags(item["description"], anthropic_client)
        db.add(Listing(
            source=item["source"],
            external_id=item["external_id"],
            title=item["title"],
            org=item["org"],
            type=item["type"],
            location=item["location"],
            description=item["description"],
            tags=tags,
            deadline=item["deadline"],
            apply_url=item["apply_url"],
        ))
        stored_count += 1
    db.commit()
    return stored_count


def run_scan_for_user(db: Session, user_id: str) -> dict:
    """Re-scores current listings for one user and stores the results.
    Used both by the daily scheduled job and the manual /listings/scan/{user_id} route.
    """
    profile = (
        db.query(Profile)
        .filter(Profile.user_id == user_id, Profile.is_current == True)  # noqa: E712
        .first()
    )
    if not profile:
        return {"status": "no active profile", "user_id": user_id}

    listings = db.query(Listing).all()
    ranked = rank_listings(
        [_listing_to_dict(l) for l in listings],
        _profile_to_dict(profile),
        top_n=10,
    )

    # Determine this user's next scan_cycle number
    last_cycle = (
        db.query(MatchScore.scan_cycle)
        .filter(MatchScore.user_id == user_id)
        .order_by(MatchScore.scan_cycle.desc())
        .first()
    )
    next_cycle = (last_cycle[0] + 1) if last_cycle else 1

    for l in ranked:
        db.add(MatchScore(
            user_id=user_id,
            listing_id=l["id"],
            profile_id=profile.id,
            score_pct=l["score_pct"],
            goal_match_tags=l["goal_match_tags"],
            skill_match_tags=l["skill_match_tags"],
            rationale=l["rationale"],
            scan_cycle=next_cycle,
        ))
    db.commit()

    return {"status": "scanned", "user_id": user_id, "matches": len(ranked), "cycle": next_cycle}


def run_scan_for_all_users():
    """The actual daily job: pulls fresh listings once, then re-scores
    every user against the updated listings table.
    """
    db = SessionLocal()
    try:
        print(f"[{datetime.utcnow().isoformat()}] Starting daily scan...")
        new_count = asyncio.run(_pull_and_store_new_listings(db))
        print(f"Pulled {new_count} new listings.")

        users = db.query(User).join(Profile).filter(Profile.is_current == True).all()  # noqa: E712
        for user in users:
            result = run_scan_for_user(db, str(user.id))
            print(f"  {user.email}: {result}")
        print("Daily scan complete.")
    except Exception as e:
        print(f"Scan failed: {e}")
    finally:
        db.close()


def start_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(run_scan_for_all_users, "interval", minutes=SCAN_INTERVAL_MINUTES)
    scheduler.start()
    return scheduler
